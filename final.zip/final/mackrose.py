#library
from pynput.mouse import Controller as MouseController, Button
from pynput.keyboard import Controller as KeyboardController, Key
from pynput.keyboard import Listener, Key, KeyCode
import threading
import tkinter as tk
import time
import random
import math
import sys


#create window and name and size and stuff
mouse = MouseController()
keyboard_controller = KeyboardController()
root = tk.Tk()
root.title("Mack Rose")
root.attributes("-topmost", True)
root.resizable(False, False)
x = (root.winfo_screenwidth() // 2) - 235 # get middle of width of screen, subtract 235 because that is the size of the window
y = (root.winfo_screenheight() // 2) - 265 # middle of height of screen, subtract 265 because that is the size of the window
root.geometry(f"470x530+{x}+{y}") # set window in the middle

#le global variables
offset = 0 # time until the auto clicker will click again
running = False # if the auto clicker is running, it will be true
keyrunning = False # if the auto key presser is running, it will be true
delay = 0 # how long the auto clicker will hold its clicks for
hotkey = Key.f7 # key that the auto clicker will use to activate/deactivate
key_clicker_hotkey = Key.f8 # key that the auto presser will use to activate/deactivate
choosing = False # If you are currently changing anything with the program, such as changing a hotkey or removing a button from the key presser
keys = [] # The list which stores all the keys which they key presser presses
global presstime_after
presstime_after = None
key_listener = None
active_listener = None
scheduled_events = []  # Global list to store root.after IDs
stupidkeys = ['{end}', '{down}', '{page_down}', '{left}', '{right}', '{home}', '{up}', '{page_up}', '{num_lock}', '{caps_lock}', '{esc}', '{ctrl_l}', '{cmd}', '{alt_l}', '{alt_gr}', '{ctrl_r}', ] # List of keys which I don't want to add in

# returns false when given a true, and true when given false.
def flipflop(boolean):
    return not boolean

def show_error(error):
    #define window
    window = tk.Toplevel(root)
    window.resizable(False, False)
    window.title('Error')
    window.transient(root) #ontop of root
    window.grab_set() # modal: blocks interaction with root
    window.lift()
    root.attributes("-topmost", True)

    # content of window
    tk.Label(window, text=f"Error: \n{error}", padx=50, pady=25,).pack()
    tk.Button(window, text="OK", width=12, command=window.destroy).pack(pady=(0,12))

    #calculate position of window
    root.update_idletasks() # tk measures root
    window.update_idletasks() # tk measures the window'

    # set position of window
    window_x = root.winfo_x()
    window_y = root.winfo_y()
    window.geometry(f"300x130+{window_x+90}+{window_y+180}") #set position
    window.update_idletasks() # tk measure window again (idk why but code doesn't work if you dont do it again)

    # end window definitions
    window.protocol("WM_DELETE_WINDOW", window.destroy) # button closes too
    window.focus_set() # sets focus to this window (nah really)
    window.wait_window() # block root until it is closed

def key_equals(a, b):
    # try vk match
    avk = getattr(a, 'vk', None)
    bvk = getattr(b, 'vk', None)
    if avk is not None or bvk is not None:
        return avk == bvk

    # try special keys like space and f7
    if isinstance(a, Key) and isinstance(b, Key):
        return a == b

    #compare chars
    achar = getattr(a, 'char', None)
    bchar = getattr(a, 'char', None)
    if achar is not None and bchar is not None:
        return achar.lower() == bchar.lower()

    return False

def defocus_on_click(event):

    # if you clicked on an entry, keep teh focus
    w = event.widget
    wclass = w.winfo_class()
    if wclass in ("Entry"):
        return

    # if some entry already is focused, clear it
    focused = root.focus_get()
    if isinstance(focused, tk.Entry):
        try:
            focused.selection_clear()
        except Exception:
            pass

    # give focus to the thing you clicked (or the root)
    try:
        w.focus_set()
    except Exception:
        root.focus.set()


# gets the time you wait until next click you put into the thing
def getoffset():
    global offset
    try:
        #get values for each box. Each is box is converted into their respective units
        mili_val = float(mili.get() or 0)
        sec_val = float(second.get() or 0) * 1000
        min_val =  float(minute.get() or 0) * 60 * 1000
        hour_val = float(hour.get() or 0) * 60 * 60 * 1000

        # craculate the total offset
        offset = mili_val + sec_val + min_val + hour_val
        return offset

    except ValueError:
        offset = 1000
        print('error with offest, wth you do?')
        return offset


# gets the time you hold a click for
def getdelay():
    global delay
    try:
        #get values for each box. Each is box is converted into their respective units
        delaymili_val = float(delay_mili.get() or 0)
        delaysec_val = float(delay_second.get() or 0) * 1000

        # craculate the total delay
        delay = delaymili_val + delaysec_val

    except ValueError:
        delay = 1000
        print('error with delay, wth you do?')

#a map for later so you can just say clicktype instead of button.clicktype
clicktype_map = {
    "Left click": Button.left,
    "Middle click": Button.middle,
    "Right click": Button.right
}

# Mapping for non-character keys
key_mapping = {
    '{space}': Key.space,
    '{enter}': Key.enter,
    '{backspace}': Key.backspace,
    '{f1}': Key.f1,
    '{f2}': Key.f2,
    '{f3}': Key.f3,
    '{f4}': Key.f4,
    '{f5}': Key.f5,
    '{f6}': Key.f6,
    '{f7}': Key.f7,
    '{f8}': Key.f8,
    '{f9}': Key.f9,
    '{f10}': Key.f10,
    '{f11}': Key.f11,
    '{f12}': Key.f12,
}

NUMPAD_MAP = {
    96: '{numpad0}',
    97: '{numpad1}',
    98: '{numpad2}',
    99: '{numpad3}',
    100: '{numpad4}',
    101: '{numpad5}',
    102: '{numpad6}',
    103: '{numpad7}',
    104: '{numpad8}',
    105: '{numpad9}',
    110: '{numpad.}',
}

def pretty_key_name(k):
    if isinstance(k, Key):
        return k.name # examples :  f7, space
    if isinstance(k, KeyCode):
        if k.vk in NUMPAD_MAP:
            return NUMPAD_MAP[k.vk].strip("{}") # "numpad1"
        if k.char:
            return k.char
    return str(k)
# Function to validate the input to allow only numbers and you can only put up to 5 digits per box
def validate_input(input_value):
    if input_value.isdigit() or input_value == "":  # Allow only digits and empty string (for deleting)
        if len(input_value) <= 5:
            return True
        else:
            return False
    else:
        return False

validate_command = root.register(validate_input)

def update_entry_states(*args):
    # Check the value of holding_delay and enable/disable boxes accordingly
    if holding_delay.get() == "Hold for..":
        delay_second.config(state="normal")  # Enable the boxes
        delay_mili.config(state="normal")
        randomness_delay_mili.config(state="normal")
    else:
        delay_second.config(state="disabled")  # Gray out the boxes
        delay_mili.config(state="disabled")
        randomness_delay_mili.config(state="disabled")

def key_update_entry_states(*args):
    # Check the value of key_holding_delay and enable/disable boxes accordingly
    if key_holding_delay.get() == "Hold for..":
        key_delay_second.config(state="normal")  # Enable the boxes
        key_delay_mlii.config(state="normal")
        randomness_delay_presser.config(state="normal")
    else:
        key_delay_second.config(state="disabled")  # Gray out the boxes
        key_delay_mlii.config(state="disabled")
        randomness_delay_presser.config(state="disabled")

# FRAMES vvvv

offset_frame = tk.LabelFrame(root, text=" Click Offset ", font=("Arial", 8), padx=10, pady=10)
offset_frame.place(x=10, y=10)

type_frame = tk.LabelFrame(root, text=" Click Type and Hold Time", font=("Arial", 8), padx=10, pady=10)
type_frame.place(x=10, y=80)
root.grid_rowconfigure(4, minsize=20)

randomness_frame_offset = tk.LabelFrame(root, text=" Random Click Offset ", font=("Arial", 8), padx=10, pady=10)
randomness_frame_offset.place(x=183, y=80)

randomness_frame = tk.LabelFrame(root, text=" Random Hold Time ", font=("Arial", 8), padx=10, pady=10)
randomness_frame.place(x=327, y=80)

hotkey_frame = tk.LabelFrame(root, text=" Hotkey ", font=("Arial", 8), padx=8, pady=8)
hotkey_frame.place(x=183, y=138)


key_presser_frame = tk.LabelFrame(root, text=" Key Presser ", font=("Arial", 8), padx=10, pady=10)
key_presser_frame.place(x=10, y=250)

key_random_frame = tk.LabelFrame(root, text=" Random Key Offset ", font=("Arial", 8), padx=10, pady=10)
key_random_frame.place(x=320, y=380)

key_offset_frame = tk.LabelFrame(root, text=" Key Offset ", font=("Arial", 8), padx=10, pady=10)
key_offset_frame.place(x=320, y=265)

key_delay_frame = tk.LabelFrame(root, text=" Key Hold Time ", font=("Arial", 8), padx=10, pady=4)
key_delay_frame.place(x=20, y=450)

random_key_delay_frame = tk.LabelFrame(root, text=" Random Key Hold Time ", font=("Arial", 8), padx=10, pady=10)
random_key_delay_frame.place(x=320, y=450)


# FRAMES ^^^^

# OFFSET vvvv

hour = tk.Entry(offset_frame, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width=5)
hour.grid(row=0, column=0, padx=5)
hour.insert(0, "0")
hourtext = tk.Label(offset_frame, text="hours", font=("Arial", 8))
hourtext.grid(row=0, column=1, padx=(0, 15))

minute = tk.Entry(offset_frame, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width=5)
minute.grid(row=0, column=2, padx=5)
minute.insert(0, "0")
minutetext = tk.Label(offset_frame, text="minutes", font=("Arial", 8))
minutetext.grid(row=0, column=3, padx=(0, 15))

second = tk.Entry(offset_frame, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width=5)
second.grid(row=0, column=4, padx=5)
second.insert(0, "0")
secondtext = tk.Label(offset_frame, text="seconds", font=("Arial", 8))
secondtext.grid(row=0, column=5, padx=(0, 15))

mili = tk.Entry(offset_frame, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width=5)
mili.grid(row=0, column=6, padx=5)
mili.insert(0, "100")
militext = tk.Label(offset_frame, text="milliseconds", font=("Arial", 8))
militext.grid(row=0, column=7)

# OFFSET ^^^^

# OFFSET FOR KEYBOARD vvvv

key_second = tk.Entry(key_offset_frame, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width=5)
key_second.grid(row=1, column=1, padx=5)
key_second.insert(0, "0")
key_secondtext = tk.Label(key_offset_frame, text="seconds", font=("Arial", 8))
key_secondtext.grid(row=1, column=0, padx=(0, 15))

deadrow4 = tk.Label(key_offset_frame, text="", font=("Arial", 10))
deadrow4.grid(row=2, column=0)

key_mili = tk.Entry(key_offset_frame, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width=5)
key_mili.grid(row=3, column=1, padx=5)
key_mili.insert(0, "5")
key_militext = tk.Label(key_offset_frame, text="milliseconds", font=("Arial", 8))
key_militext.grid(row=3, column=0)


# Randomness for keyboard

randomness_offset_presser = tk.Entry(key_random_frame, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width=5)
randomness_offset_presser.insert(0, "0")
randomness_offset_presser.grid(row=0, column=1, padx=5)
randomness_offset_presser_text = tk.Label(key_random_frame, text="milliseconds", font=("Arial", 8))
randomness_offset_presser_text.grid(row=0, column=0)


randomness_delay_presser = tk.Entry(random_key_delay_frame, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width=5)
randomness_delay_presser.insert(0, "0")
randomness_delay_presser.grid(row=0, column=1, padx=5)
randomness_delay_presser_text = tk.Label(random_key_delay_frame, text="milliseconds", font=("Arial", 8))
randomness_delay_presser_text.grid(row=0, column=0)

# OFFSET FOR KEYBOARD ^^^^

# CLICK TYPE  vvvv

click_option = tk.StringVar()
click_option.set("Left click")

holding_delay = tk.StringVar()
holding_delay.set("Hold for..")
holding_delay.trace("w", update_entry_states)

key_holding_delay = tk.StringVar()
key_holding_delay.set("Hold for..")
key_holding_delay.trace("w", key_update_entry_states)

typeclick_menu = tk.OptionMenu(type_frame, click_option, "Left click", "Middle click", "Right click")
typeclick_menu.config(width=12, font=("Arial", 10)) #adjust width and font size
typeclick_menu.grid(row=0, column=0, padx=5)

holdtime_menu = tk.OptionMenu(type_frame, holding_delay, "No holding", "Hold for..", "Hold forever")
holdtime_menu.config(width=12, font=("Arial", 10)) #adjust width and font size
holdtime_menu.grid(row=3, column=0, padx=0)

key_holdtime_menu = tk.OptionMenu(key_delay_frame, key_holding_delay, "No holding", "Hold for..", "Hold forever")
key_holdtime_menu.config(width=10, font=("Arial", 10)) #adjust width and font size
key_holdtime_menu.grid(row=1, column=0, padx=0)


# CLICK TYPE  ^^^^

deadrow1 = tk.Label(type_frame, text="", font=("Arial", 10))
deadrow1.grid(row=2, column=0)
deadrow2 = tk.Label(type_frame, text="", font=("Arial", 10))
deadrow2.grid(row=4, column=0)
deadrow3 = tk.Label(type_frame, text="", font=("Arial", 10))
deadrow3.grid(row=5, column=0)

deadrow7 = tk.Label(key_delay_frame, text="", font=("Arial", 10))
deadrow7.grid(row=1, column=1)
deadrow8 = tk.Label(key_presser_frame, text="", font=("Arial", 10))

deadrow8.grid(row=333, column=0)
deadrow9 = tk.Label(key_presser_frame, text="", font=("Arial", 10))
deadrow9.grid(row=335, column=0)
deadrow10 = tk.Label(key_presser_frame, text="", font=("Arial", 10))
deadrow10.grid(row=336, column=0)

# DELAY (part of the clicktype frame)  vvvv

delay_second = tk.Entry(root, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width =5)
delay_second.insert(0, "0")
delay_second.place(x=25, y=210)

delay_secondtext = tk.Label(root, text="secs", font=("Arial", 8))
delay_secondtext.place(x=65, y=210)

delay_mili = tk.Entry(root, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width =5)
delay_mili.insert(0, "10")
delay_mili.place(x=100, y=210)

delay_militext = tk.Label(root, text="mili", font=("Arial", 8))
delay_militext.place(x=140, y=210)

# DELAY (part of the clicktype frame) ^^^^

# DELAY FOR KEY CLICKER vvvv

key_delay_second = tk.Entry(key_delay_frame, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width=5)
key_delay_second.insert(0, "0")
key_delay_second.grid(row=1, column=2, padx=5)

key_delay_secondtext = tk.Label(key_delay_frame, text="secs", font=("Arial", 8))
key_delay_secondtext.grid(row=1, column=3)


key_delay_mlii = tk.Entry(key_delay_frame, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width=5)
key_delay_mlii.insert(0, "0")
key_delay_mlii.grid(row=1, column=4, padx=5)

key_delay_mliitext = tk.Label(key_delay_frame, text="mili", font=("Arial", 8))
key_delay_mliitext.grid(row=1, column=5)


# key_delay_mlii_random = tk.Entry(key_delay_frame, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width=5)
# key_delay_mlii_random.insert(0, "0")
# key_delay_mlii_random.grid(row=1, column=2, padx=5)

# key_delay_mlii_random = tk.Label(key_delay_frame, text="mili", font=("Arial", 8))
# key_delay_mlii_random.grid(row=1, column=3)

# DELAY FOR KEY CLICKER ^^^^

# Randomness (only for clicker)  vvvv

randomness_offset_mili = tk.Entry(randomness_frame_offset, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width=5)
randomness_offset_mili.insert(0, "0")
randomness_offset_mili.grid(row=1, column=0, padx=5)

randomness_offset_militext = tk.Label(randomness_frame_offset, text="milliseconds", font=("Arial", 8))
randomness_offset_militext.grid(row=1, column=1)

randomness_delay_mili = tk.Entry(randomness_frame, validate="key", validatecommand=(validate_command, "%P"), font=("Arial", 10), width=5)
randomness_delay_mili.insert(0, "0")
randomness_delay_mili.grid(row=3, column=0, padx=5)

randomness_delay_militext = tk.Label(randomness_frame, text="milliseconds", font=("Arial", 8))
randomness_delay_militext.grid(row=3, column=1)

update_entry_states() # updates the boxes to see if they should be grayed out or nah
key_update_entry_states()
# Randomness (only for clicker) ^^^^

# KEY PRESSER VVV

# creates the list box widget and puts it down
KeysPressing = tk.Listbox(key_presser_frame, height=10, width=26)
for item in keys:
    KeysPressing.insert(tk.END, item)
KeysPressing.grid(row=0, column=0, padx=0)

# creates scroll bar for the list widget
scrollbar = tk.Scrollbar(root)
scrollbar.place(x=170, y=260, height=180)
KeysPressing.config(yscrollcommand=scrollbar.set)
scrollbar.config(command=KeysPressing.yview)


#removes all keys in the keys and keyspressing list
def remove_all():
    global keys, KeysPressing
    if not keyrunning and not choosing and not running:
        for x in range(len(keys)-1, -1, -1):
            keys.pop(x)
            KeysPressing.delete(x)
        print('All keys removed')

# Adds the key pressed from add_aKey() into keys[] list

def add_presserKey(key):
    global choosing, keys, active_listener
    try:
        # check if key is None
        if key is None or str(key) == 'None':
            print('empty key, ignoring')
            return

        # check if it is a modifier key
        if key in [Key.shift, Key.ctrl, Key.alt]:
            print('Modifier key detected')
            return

        # Convert the key to a string
        if hasattr(key, 'char') and key.char is not None:  # Character key (e.g., 'a', 'b', '1')
            key_combination = key.char
        elif hasattr(key, 'name'):  # Non-character key (e.g space, enter)
            key_combination = str(key).replace('Key.', '{').lower() + '}'
        elif hasattr(key, 'vk'):
            # check if it's a numpad vk
            numpad_map = {
                96: '{numpad0}',
                97: '{numpad1}',
                98: '{numpad2}',
                99: '{numpad3}',
                100: '{numpad4}',
                101: '{numpad5}',
                102: '{numpad6}',
                103: '{numpad7}',
                104: '{numpad8}',
                105: '{numpad9}',
                }
            if key.vk in numpad_map:
                key_combination = numpad_map[key.vk]
            else:
                show_error(f'Invalid key "{key}"')
                print(f"Ignoring raw keycode: {key}")
                return
        # Skip if key is invalid
        else:
            show_error(f'Invalid key "{key}"')
            print("Unsupported key type, ignoring.")
            return

        if key == hotkey or key == key_clicker_hotkey:
            show_error('Can\'t put a key which is already a hotkey')
            print('Can\'t put in key which already is a hotkey')
            return
        if key_combination in stupidkeys:
            show_error(f'Key "{key}" not supported')
            print('Key not supported')
            return

        # add key
        keys.append(key_combination)
        KeysPressing.insert(tk.END, key_combination)
        print(f"Added key '{key_combination}'")
        add_key_button.config(text="Add key")
        choosing = False

        # Stop the listener
        if active_listener:
            active_listener.stop()
            active_listener = None

    except AttributeError:
        print("Non-character key detected, ignoring.")


# Removes the key pressed from remove_aKey() from keys and KeysPressing
def remove_presserKey():
    global choosing, keys, active_listener
    # removes last index of keys pressing and keys
    try:
        index_to_remove = len(keys) - 1
        keys.pop(index_to_remove)
        KeysPressing.delete(index_to_remove)
        print("Last index removed.")
        choosing = False

        # nothing in list
    except IndexError:
        print('Nothing in list')

# old model for remove key:
# def remove_presserKey(key):
#     global choosing, keys, active_listener
#     try:
#         # Convert the key to a string
#         if hasattr(key, 'char') and key.char is not None:  # Character key (e.g., 'a', 'b', '1')
#             key_to_remove = key.char
#         else:  # Non-character key (e.g., space, enter, F8)
#             key_to_remove = str(key).replace('Key.', '{').lower() + '}'
#             key_to_remove = key_to_remove.replace('{backspace}', '{backspace}')  # Fix for backspace

#         # Remove the key from the list
#         if key_to_remove in keys:
#             index_to_remove = len(keys) - 1 - keys[::-1].index(key_to_remove)
#             keys.pop(index_to_remove)
#             KeysPressing.delete(index_to_remove)
#             print(f"Key '{key_to_remove}' removed.")
#         else:
#             print(f"Key '{key_to_remove}' not found.")
#         remove_key_button.config(text="Remove key")
#         choosing = False

        # Stop the listener
        if active_listener:
            active_listener.stop()
            active_listener = None
    except AttributeError:
        print("Non-character key detected, ignoring.")

# for the frame
deadrow5 = tk.Label(key_presser_frame, text="                                                                  ", font=("Arial", 10))
deadrow5.grid(row=0, column=3)

deadrow6 = tk.Label(hotkey_frame, text="", font=("Arial", 10))
deadrow6.grid(row=0, column=1)

def add_aKey():
    global choosing, active_listener
    if not keyrunning and not running:
        choosing = True
        add_key_button.config(text='Press any key')

        # Cancel and end listener
        if active_listener:
            print('Canceled')
            active_listener.stop()
            active_listener = None
            choosing = False
            change_hotkey.config(text=f"Change clicker \n hotkey ({pretty_key_name(hotkey)})" )
            change_presser_hotkey.config(text=f"Change key \n presser hotkey \n ({pretty_key_name(key_clicker_hotkey)})")
            add_key_button.config(text='Add key')

        else:
            # Start a new listener
            active_listener = Listener(on_press=add_presserKey)
            active_listener.start()

def remove_aKey():
    global choosing, active_listener
    if not keyrunning and not running:
        remove_presserKey()

add_key_button = tk.Button(
    root,
    text="Add key",                    # Button text
    font=("Arial", 10),                # Bigger font
    padx=9, pady=10,                   # Add padding
    width=10, height=1,                # Set explicit size
    command=add_aKey                   # Function to call
)
add_key_button.place(x=200, y=270)

remove_key_button = tk.Button(
    root,
    text="Remove last key",                 # Button text
    font=("Arial", 10),                # Bigger font
    padx=9, pady=10,                   # Add padding
    width=10, height=1,                # Set explicit size
    command=remove_aKey                # Function to call
)
remove_key_button.place(x=200, y=330)

remove_all_button = tk.Button(
    root,
    text="Remove All",                 # Button text
    font=("Arial", 10),                # Bigger font
    padx=9, pady=10,                   # Add padding
    width=10, height=1,                # Set explicit size
    command=remove_all                 # Function to call
)
remove_all_button.place(x=200, y=390)

# KEY PRESSER ^^^^

# HOTKEY FOR AUTOCLICKER VVV

# (Comes AFTER record_key() function) Will stop recording the next key press  to set it to variable hotkey, and set text back to normal
def change_key(key):
    global choosing, hotkey, active_listener, key_clicker_hotkey
    # Convert the key to a string representation for comparison
    if hasattr(key, 'char') and key.char is not None:
        key_str = key.char
        new_hotkey = key
    elif hasattr(key, 'name'):
        key_str = str(key).replace('Key.', '{').lower() + '}'
        new_hotkey = key
    elif hasattr(key, 'vk'):
        if key.vk in NUMPAD_MAP:
            key_str = NUMPAD_MAP[key.vk]
            new_hotkey = KeyCode(vk=key.vk)
        else:
            print('Unsupported vk:', key.vk)
            show_error(f'Unsupported key: "{key.vk}"')
            return
    else:
        print('Invalid key type')
        show_error(f'Invalid key: "{key_str}"')
        return

    # Prevent conflicts
    if key_str in keys:
        print('Keyis already in the key presser list')
        show_error(f'Key "{key_str}" is already in presser list')
        return

    hotkey = new_hotkey
    print(f'Hotkey changed to {key_str}')

    # update label with pretty name
    if active_listener:
        active_listener.stop()
    change_hotkey.config(
        text=f"Change clicker \n hotkey ({pretty_key_name(hotkey)})"
        )
    active_listener = None
    choosing = False

# Records the next key press while changing the text. sets choosing to true which makes it so autoclicker won't run if it is true
def record_key():
    global choosing, active_listener
    if active_listener:
        active_listener.stop()
        active_listener = None
        print('Canceled')
        change_hotkey.config(text=f"Change clicker \n hotkey ({pretty_key_name(hotkey)})" )
        change_presser_hotkey.config(text=f"Change key \n presser hotkey \n ({pretty_key_name(key_clicker_hotkey)})")
        add_key_button.config(text="Add key")
        choosing = False
        return

    if not choosing and not running:
        choosing = True
        change_hotkey.config(text='Press any key')

        # Start a new listener
        active_listener = Listener(on_press=change_key)
        active_listener.start()

# Creates the hotkey button
change_hotkey = tk.Button(
    hotkey_frame,
    text="Change clicker \n hotkey ("+ str(hotkey.name) + ")",  # Button text
    font=("Arial", 10),                 # Bigger font
    padx=9, pady=10,                    # Add padding
    width=12, height=3,                 # Set explicit size
    command=record_key                  # Function to call
)
# places hotkey button


change_hotkey.grid(row=0, column=0, padx=3)


# same thing but for presser

def presser_change_key(key):
    global choosing, key_clicker_hotkey, active_listener, hotkey

    # normalize key_str for checks and albels and consisentisy in hotkey object
    if hasattr(key, 'char') and key.char is not None:
        key_str = key.char
        new_hotkey = key 
    elif hasattr(key, 'name'):
        key_str = str(key).replace('Key.', '{').lower() + '}'
        new_hotkey = key
    elif hasattr(key, 'vk'):
        if key.vk in NUMPAD_MAP:
            key_str = NUMPAD_MAP[key.vk]
            new_hotkey = KeyCode(vk=key.vk)
        else:
            print('Unsupported vk:', key.vk)
            show_error(f'Unsupported key: {key.vk}')
            return
    else:
        print('Invalid key type')
        show_error(f'Invalid key: "{key_str}"')
        return

    # Prevent conflicts
    if key_str in keys:
        print('Key is already in the key presser list')
        show_error(f'Key "{key_str}" is already in key presser list')
        return

    key_clicker_hotkey = new_hotkey
    print(f'Hotkey changed to {key_str}')

    # update label with pretty name
    if active_listener:
        active_listener.stop()
    change_presser_hotkey.config(
        text=f"Change key \n presser hotkey \n ({pretty_key_name(key_clicker_hotkey)})"
        )
    active_listener = None
    choosing = False

# Records the next key press while changing the text. sets choosing to true which makes it so autoclicker won't run if it is true
def presser_record_key():
    global choosing, active_listener
    if active_listener:
        active_listener.stop()
        active_listener = None
        print('Canceled')
        change_hotkey.config(text=f"Change clicker \n hotkey ({pretty_key_name(hotkey)})" )
        change_presser_hotkey.config(text=f"Change key \n presser hotkey \n ({pretty_key_name(key_clicker_hotkey)})")
        add_key_button.config(text="Add key")
        choosing = False
        return

    if not choosing and not running:
        choosing = True
        change_presser_hotkey.config(text='Press any key')

        # Start a new listener
        active_listener = Listener(on_press=presser_change_key)
        active_listener.start()


change_presser_hotkey = tk.Button(
    hotkey_frame,
    text="Change key \n presser hotkey \n ("+ str(key_clicker_hotkey.name) + ")",  # Button text
    font=("Arial", 10),                 # Bigger font
    padx=9, pady=10,                    # Add padding
    width=12, height=3,                 # Set explicit size
    command=presser_record_key          # Function to call
)

change_presser_hotkey.grid(row=0, column=2, padx=2)

# HOTKEY FOR AUTOCLICKER ^^^

# MAIN FUNCTION vvvv

# main program

def presstime():
    global presstime_after, scheduled_events, keyrunning
    # calculate next interval…
    random_offset = int(randomness_offset_presser.get() or 0)
    key_presstime = len(keys) + 5 + int(key_mili.get() or 0) + int(key_second.get() or 0) * 1000
    key_presstime += random.randint(-random_offset, random_offset)

    # calculate total hold time for "Hold for.."…
    random_delay = int(randomness_delay_presser.get() or 0)
    total_hold = int(key_delay_second.get() or 0) * 1000 + int(key_delay_mlii.get() or 0)
    total_hold -= random.randint(-random_delay, random_delay)

    if not keyrunning or not keys:
        print('Key presser stopped or no keys to press')
        return

    mode = key_holding_delay.get()

    # Press the keys if the mode is not hold forever
    def finish_sequence():
        if not keyrunning:
            return
        if mode != "Hold forever":
            nxt = root.after(key_presstime, presstime)
            scheduled_events.append(nxt)
            print(f'Next key press in {key_presstime/1000:.3f}s\n')
        else:
            print('Holding keys forever…')

    def press_seq(i=0):
        if not keyrunning:
            return
        if i >= len(keys):
            finish_sequence()
            return

        ks = keys[i]
        kobj = key_mapping.get(ks, ks)
        keyboard_controller.press(kobj)
        print(f'Key {ks} pressed in mode "{mode}"')

        if mode == "No holding":
            # release immidieatly and then press the next key
            keyboard_controller.release(kobj)
            root.after(0, lambda: press_seq(i + 1))

        elif mode == "Hold for..":
            # wait for total_hold ms, then go to the next key
            def release_and_next(k=kobj, idx=i):
                keyboard_controller.release(k)
                root.after(0, lambda: press_seq(idx + 1))
            root.after(total_hold, release_and_next)


        else:
            root.after(0, lambda: press_seq(i + 1))

    press_seq(0)

def clicktime():
    getoffset()
    random_offset_absvalue = int(randomness_offset_mili.get() or 0)                     # abs value of random offset box
    random_offset = random.randint(random_offset_absvalue * -1, random_offset_absvalue) # gets a random value from neagative abs value to abs value

    getdelay()
    random_delay_absvalue = int(randomness_delay_mili.get() or 0)                    # abs value of random delay box
    random_delay = random.randint(random_delay_absvalue * -1, random_delay_absvalue) # gets a random value from neagative abs value to abs value
    hold_time_ms = int(delay) - int(random_delay)                                    # calculates the random delay value

    clicktype = clicktype_map.get(click_option.get(), Button.left) #gets clicktype

    if running:
        if holding_delay.get() == "No holding":
            mouse.click(clicktype)

        elif holding_delay.get() == "Hold for..":
            mouse.press(clicktype)
            root.after(hold_time_ms, lambda: release_click(clicktype))

        else: # holding_delay.get() == "Hold forever"
            mouse.press(clicktype)
            print('Holding forever...')
            return

        # tells you the result
        print('')
        print(f"Type                : {click_option.get()}.")
        print(f"The holding will be : {holding_delay.get()}")
        print(f"It will hold for    : {hold_time_ms/1000} seconds.")
        print(f"{(offset/1000) + float(random_offset/1000)} seconds until next click...")
        root.after(int(offset + random_offset), clicktime)

# attempts to stop holding when you turn the program off
def release_click(clicktype):
        mouse.release(clicktype)

# Turns on/off the clicking if the condiditions allow it to
def on_button_click():
    global running
    if not choosing:
        running = flipflop(running)
        clicktime()
        if not running:
            print('\nEND CLICKER')
            clicktype = clicktype_map.get(click_option.get(), Button.left)
            mouse.release(clicktype)

def on_keyclicker_click():
    global keyrunning, presstime_after, scheduled_events
    if not choosing:
        keyrunning = not keyrunning
        if keyrunning and keys:
            presstime()
        else:
            # cancel all scheduled callbacks
            for eid in scheduled_events:
                root.after_cancel(eid)
            scheduled_events.clear()
            if presstime_after:
                root.after_cancel(presstime_after)
                presstime_after = None

            # now release any keys still held
            for ks in keys:
                kobj = key_mapping.get(ks, ks)
                try:
                    keyboard_controller.release(kobj)
                except Exception:
                    pass

            print('\nEND PRESSER')

def selfdestructer():
    root.destroy()
    sys.exit()

# bind defocus on click to left click. add"+" makes it so it won't delete any other bindings
root.bind_all("<Button-1>", defocus_on_click, add="+")
# space no longer activates buttons
root.unbind_class("Button", "<space>")

def on_press(key):
    try:
        if key == Key.f1:
            print('ayo da pizza here')
            selfdestructer()

        if key_equals(key, hotkey):
            on_button_click()
        elif key_equals(key, key_clicker_hotkey):
            on_keyclicker_click()

    except AttributeError:
        pass

def start_listener():
    with Listener(on_press=on_press) as listener:
        listener.join()

listener_thread = threading.Thread(target=start_listener, daemon=True)
listener_thread.start()

#main
root.mainloop()



